<?php

$lang['welcome'] = 'Welcome';
$lang['hello word'] = 'Hello Word';








//Account Sub Types & Legders
$lang['name'] = 'Name';
$lang['address'] = 'Address';
$lang['code'] = 'Code';
$lang['type'] = 'Type';
$lang['acc_type_id'] = 'Account Type';
$lang['acc_sub_type_id'] = 'Sub Type';
$lang['openning_bal'] = 'Opening Balance';
$lang['main_legder'] = 'Main Ledger';
$lang['acc_main_id'] = 'Account Main';
$lang['tax_id'] = 'Tax';
$lang['unit_id'] ='Unit';
$lang['unit_count'] = 'Unit Count';
$lang['start_date'] = 'Start Date';
$lang['end_date'] = 'End Date';
//Item Category Master
$lang['item_category_id'] ='Parent'; 
$lang['mrp'] = ''; //MRP
$lang['Batch'] = '';//,,,,
$lang['godown_name'] = '';
$lang['godown_address'] = '';
$lang['godown_contactno'] = '';
$lang['godown_contact_person'] = '';
$lang['company'] = '';
$lang['Qty'] = ''; //Quantity
$lang['Dis Amt'] = ''; //Discount Amount
$lang['Prate'] = ''; ////Purchase Rate
$lang['Dis'] = ''; //Discount
$lang['Tax(AMT)'] = ''; //Tax Amount
$lang['ListName'] = '';//'ListName','parent','Url','icon','menu_series'
$lang['parent'] = 'Parent'; //main category
$lang['main'] = 'Main Type';
$lang['Url'] = 'URL';
$lang['icon'] = 'Icon';
$lang['menu_series'] = 'Menu Order'; //series no.
$lang['user_name'] = 'Name';
$lang['user_type'] = 'User Type';
$lang['user_address'] = 'Address';
$lang['user_mobile'] = 'Mobile';
$lang['user_phone'] = 'Phone';
$lang['user_email'] = 'Email';
$lang['username'] = 'Username';
$lang['user_password'] = 'Password';
$lang['company'] = 'Company';
$lang['	is-active'] = 'Is Active';
$lang['branch'] = 'Branch';
$lang['Cess'] = 'Cess';
$lang['ces_name'] = 'Cess';
$lang['ces_percent'] = 'Percentage';
$lang['ibr_name'] = 'Brand'; //Brand Name
$lang['ibr_description'] = 'Description'; // Description for brand



//Church ,Clinic, Tailoring Menus
  $lang['Church'] = '';
  $lang['Prayer Community Master'] = '';
  $lang['Wards Master'] = '';
  $lang['Family Register'] = '';
  $lang['Districts Master'] = '';
  $lang['Villages Master'] = '';
  $lang['Taluk Master'] = '';
  $lang['Diocese Master'] = '';
  $lang['Land/locality Master'] = '';
  $lang['Relationship Master'] = '';
  $lang['Receipt types'] = '';
  $lang['Receipt generate'] = '';
  $lang['Receipts Status'] = '';
  $lang['Tailoring'] = '';
  $lang['Size Master'] = '';
  $lang['Item Master'] = '';
  $lang['Customer - Tailoring'] = '';
  $lang['Sales - Tailoring'] = '';
  $lang['Baptism Register'] = '';
  $lang['Death Register'] = '';
  $lang['Marriage Register'] = '';
  $lang['Fathers'] = '';
  $lang['Parish Master'] = '';
  $lang['Clinic'] = '';
  $lang['Blood Group'] = '';
  $lang['Time Schedule'] = '';
  $lang['Patients'] = '';
  $lang['Doctors'] = '';
  $lang['Appointments'] = '';
  $lang['Calendar'] = '';
  $lang['Procedures'] = '';
  $lang['My Patients'] = '';
  $lang['Payment/Pharmacy'] = '';
  $lang['Approval'] = '';
  $lang['Patient History'] = '';