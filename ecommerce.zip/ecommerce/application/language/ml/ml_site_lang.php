<?php

$lang['welcome'] = 'സ്വാഗതം';
$lang['hello word'] = 'worde Witaj';
$lang['Account Sub Types'] = 'അക്കൗണ്ട് ഉപവിഭാഗം';
$lang['Dashboard'] = 'Test';
$lang['name'] = 'പേര്';
$lang['code'] = 'കോഡ്';
$lang['type']='വിഭാഗം';
$lang['sub type']='ഉപവിഭാഗം';
$lang['actions']='പ്രവർത്തനങ്ങൾ';
$lang['open balance']='തുടക്ക സംഖ്യ';
$lang['main ledger']='പ്രധാന ലഡ്ജർ';
$lang['tax']='നികുതി';
$lang['start date']='തുടങ്ങുന്ന ദിവസം';
$lang['end date']='അവസാന ദിവസം';
$lang['unit count']='യൂണിറ്റ് എണ്ണം';
$lang['phone']='ഫോൺ';
$lang['email']='ഇമെയിൽ';
$lang['address']='വിലാസം';
$lang['cheque']='ചെക്ക്';

