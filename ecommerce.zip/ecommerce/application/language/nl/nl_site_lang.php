<?php

$lang['welcome'] = 'Welkom';
$lang['hello word'] = 'worde Witaj';